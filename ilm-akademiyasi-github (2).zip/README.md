# Ilm Akademiyasi

GitHub Pages uchun tayyor sayt (Telegram Mini App ham, oddiy sayt ham, oflayn o'rnatiladigan ilova ham).

## GitHub Pages'ga qo'yish (404 chiqmasligi uchun)
1. Repozitoriyga **hamma fayllarni** yuklang. `index.html` albatta **ildizda** (papka ichida emas) bo'lishi kerak.
2. Repo → **Settings → Pages → Build and deployment**
   - Source: **Deploy from a branch**
   - Branch: **main** / **(root)** → Save
3. 1–2 daqiqadan keyin sayt ochiladi: `https://FOYDALANUVCHI.github.io/REPO/`

## Kontent qo'shish (`content.json`)
- `banner`: bosh sahifadagi e'lon `{ "text": "...", "url": "https://..." }`
- `words`: kunlik so'z o'yini uchun 5 harfli so'zlar (kichik lotin harflari)
- `items`: yangi slaydlar yoki testlar
  - `{ "type": "deck", "title": "Nom", "e": "📘", "s": [["Sarlavha", "Matn", "Izoh"]] }`
  - `{ "type": "quiz", "title": "Nom", "q": [["Savol", "To'g'ri", "Xato1", "Xato2", "Xato3"]] }`
- `q`: fanlar bo'yicha savollar `{ "mat": [[1, "Savol", "To'g'ri", "X1", "X2", "X3"]] }` (1 = oson, 2 = o'rta, 3 = qiyin)

`content.json` ni tahrirlab commit qilsangiz, sayt o'zi yangilanadi.

## Yangi imkoniyat: ilova sifatida o'rnatish
Telefonda Chrome'da sayt ochilganda pastda chapda **📲 O'rnatish** tugmasi chiqadi. O'rnatilgach ilova internetsiz ham ochiladi.
